let src = `https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=geometry,drawing,places&key=AIzaSyB_-_DHm-yLCx0o0sfdBj1vxtL4LMUjGnM`;
location.href = src;
