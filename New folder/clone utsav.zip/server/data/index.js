module.exports = {
  data: require("./data"),
  weather: require("./weather"),
  base: require("./base"),
  flight: require("./flight"),
};
